"""
TaskManager SDK
===============

A simple SDK for managing tasks.
"""
