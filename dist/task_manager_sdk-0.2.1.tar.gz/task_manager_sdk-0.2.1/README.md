# TaskManager SDK

Este es un SDK simple para interactuar con la API de TaskManager.

## Instalación

```bash
pip install task_manager_sdk
```
